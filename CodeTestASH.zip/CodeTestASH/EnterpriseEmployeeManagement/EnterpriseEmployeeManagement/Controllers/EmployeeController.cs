using Microsoft.AspNetCore.Mvc;
using EnterpriseEmployeeManagement;

namespace EnterpriseEmployeeManagement.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeeController : ControllerBase
    {

        private readonly ILogger<EmployeeController> _logger;

        public EmployeeController(ILogger<EmployeeController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetAllEmployees")]
        public IEnumerable<Employee> Get([FromBody]EmployeeInputParameter emp)
        {
            emp.Validate();
            EmployeeDBLayer employeeDBLayer = new EmployeeDBLayer();
            AppManager appManager = new AppManager();
            return appManager.GetEmployees(emp, employeeDBLayer);
        }

        [HttpPost(Name = "AddEmployee")]
        public Employee AddEmployee([FromBody]EmployeeInputParameter emp) 
        {
            emp.Validate();
            EmployeeDBLayer employeeDBLayer = new EmployeeDBLayer();
            AppManager appManager = new AppManager();
            return appManager.AddEmployee(emp, employeeDBLayer);
        }
    }
}