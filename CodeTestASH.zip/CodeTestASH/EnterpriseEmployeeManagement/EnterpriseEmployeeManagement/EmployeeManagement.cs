﻿namespace EnterpriseEmployeeManagement
{
    public class DBObject
    {

    }

    public class Employee:DBObject
    {
        public int EmployeeId { get; set;}

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Address1 { get; set; }

        public string Address2 { get; set; }

        public string City { get; set; }   

        public string State { get; set; }

        public string EmployeeType { get; set; }

    }
    
    public class ManagerTable: DBObject
    {
        public int ManagerId { get; set; }

        public int EmployeeId { get; set; }

        public int MaxExpenseAccount { get; set; }

    }

    public class Supervisor: DBObject
    {
        public string SuperVisorId { get; set; }

        public string EmployeeId { get; set; }
    }

    public class Salary: DBObject
    {
        public int SalaryId { get; set; }

        public int EmployeeId { get; set; }

        public DateTime Year { get; set; }

        public int SalaryAmount { get; set; }
    }

    public class HourlyEmployee:DBObject
    {
        public int HourlySalaryId { get; set; }

        public int EmployeeId { get; set; }

        public string HourlySalaryType { get; set; }

        public int HourlySalaryAmount { get; set; }
    }

    public class TInputParameter
    {
        public virtual bool Validate()
        {
            throw new NotImplementedException();
        }

    }

    public class EmployeeInputParameter: TInputParameter
    {
        public override bool Validate()
        {
            throw new NotImplementedException();
        }
    }

    public interface IDBLayer<in T, out T1> where T1:DBObject
        where T: TInputParameter
    {
        public T1 CreateRecord(T record);

        public T1 UpdateRecord(T record);

        public void DeleteRecord(T record);

        public T1 GetRecord(T record);
    }

    public interface IDBCollection<in T, out T1> 
    {
        public T1 GetRecords(T record);
    }

    public class AppManager
    {
        // Note, the GetEmployees must act with the interface not with the implementation.
        public IEnumerable<Employee> GetEmployees(EmployeeInputParameter employeeInputParameter, EmployeeDBLayer employeeDBLayer)
        {
            employeeInputParameter.Validate();
            return employeeDBLayer.GetRecords(employeeInputParameter).ToList();
        }

        // Note, the GetEmployees must act with the interface not with the implementation.
        public Employee AddEmployee(EmployeeInputParameter employeeInputParameter, EmployeeDBLayer employeeDBLayer)
        {
            employeeInputParameter.Validate();
            return employeeDBLayer.CreateRecord(employeeInputParameter);
        }
    }

    // Moq class for the implementation and for unit testing.
    public class MoqDBLayer: IDBLayer<TInputParameter,Employee>,IDBCollection<TInputParameter,List<Employee>>
    {
        public Employee CreateRecord(TInputParameter param)
        {
            throw new NotImplementedException();
        }

        public Employee UpdateRecord(TInputParameter param)
        {
            throw new NotImplementedException();
        }

        public void DeleteRecord(TInputParameter param)
        {
            throw new NotImplementedException();
        }

        public Employee GetRecord(TInputParameter param)
        {
            throw new NotImplementedException();
        }

        public List<Employee> GetRecords(TInputParameter param)
        {
            throw new NotImplementedException();
        }
    }

    public class EmployeeDBLayer : IDBLayer<TInputParameter, Employee>, IDBCollection<TInputParameter, List<Employee>>
    {
        public Employee CreateRecord(TInputParameter param)
        {
            throw new NotImplementedException();
        }

        public Employee UpdateRecord(TInputParameter param)
        {
            throw new NotImplementedException();
        }

        public void DeleteRecord(TInputParameter param)
        {
            throw new NotImplementedException();
        }

        public Employee GetRecord(TInputParameter param)
        {
            throw new NotImplementedException();
        }

        public List<Employee> GetRecords(TInputParameter param)
        {
            throw new NotImplementedException();
        }
    }
}
