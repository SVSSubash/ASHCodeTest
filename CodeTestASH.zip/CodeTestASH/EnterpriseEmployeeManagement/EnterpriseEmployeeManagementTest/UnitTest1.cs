using EnterpriseEmployeeManagement;

namespace EnterpriseEmployeeManagementTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestGetEmployees()
        {
            // Arrange
            EmployeeInputParameter employeeInputParameter = new EmployeeInputParameter();
            employeeInputParameter.Validate();
            MoqDBLayer moq = new MoqDBLayer();
            AppManager appManager = new AppManager();

            // Act
            List<Employee> result = appManager.GetEmployees(employeeInputParameter, moq);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Count, 1);
        }

        [TestMethod]
        public void TestAddEmployee()
        {
            // Arrange
            EmployeeInputParameter employeeInputParameter = new EmployeeInputParameter();
            employeeInputParameter.Validate();
            MoqDBLayer moq = new MoqDBLayer();
            AppManager appManager = new AppManager();

            // Act
            Employee result = appManager.AddEmployee(employeeInputParameter, moq);

            // Assert
            Assert.IsNotNull(result);
        }
    }
}